<template>
  <div id="app">
    <router-view/>
  </div>
</template>



<style>
*{
  margin:0;
}
</style>
